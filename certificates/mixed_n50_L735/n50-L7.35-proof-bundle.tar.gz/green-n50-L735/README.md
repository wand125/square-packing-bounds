# n=50, L=7.35 certificate

Certified nonnegative measure mass: 4999999/100000 = 49.99999 < 50. Core side B=9977/10000. All 201 net angles passed outward-rounded verification and regenerated-input replay. The net margin extends coverage to every square angle and position; the certificate states the disjoint-core obstruction for 50 closed unit squares in a closed square container of side 7.35.

Green comparison: 2*sqrt(2) + 101/25 + 3*sqrt(14)/25. Integer-square-root bounds with denominator 10^90 certify improvement > 0.0325739888409369. See final-audit.json for exact rational bounds.

Provenance: direct structured L7.40 rectangle initialization, contraction to L7.35, then nonnegative minimum-L1 repair retaining native constraints and exact deficit witnesses. This artifact does not establish L7.40.

## Reproduce

Use Python 3 with numpy, scipy, numba and highspy available, and a C++17 compiler (g++). Run from any working directory:

    python3 audit.py
    python3 replay.py --workers 2

The audit checks candidate geometry/mass, hashes, all 201 first-pass and replay records, the net margin and exact Green comparison. replay.py regenerates all inputs and recomputes every angle with the same outward-rounded C++ implementation. This is not a second independent algorithm or a proof-assistant formalization. Replay may take hours.

SHA256.json covers packaged data and sources. No generated native binaries are shipped.
