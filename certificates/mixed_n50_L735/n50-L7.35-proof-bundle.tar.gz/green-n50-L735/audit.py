"""Final certificate audit. Refuse incomplete replay; never run a new proof."""
import json,sys,hashlib,math
from fractions import Fraction as F
from pathlib import Path
b=Path(__file__).resolve().parent;root=b;sys.path.insert(0,str(root/'src'))
from unified_measure import validate,net_check
from mixed_net_audit import net_certificate
p=b/'proof'
if not (p/'certificate.json').exists():
 print('REPLAY_PENDING_NO_FINAL_CERTIFICATE');raise SystemExit(2)
certificate=json.loads((p/'certificate.json').read_text())
summary=json.loads((p/'summary.json').read_text())
progress=json.loads((p/'replay-progress.json').read_text())
assert certificate['status']==summary['status']=='ALL_LINEAR_ANGLES_VERIFIED_AND_REPLAYED'
assert summary['globally_verified'] is True and summary['complete_angles']==summary['verified_angles']==201
assert progress==dict(done=201,total=201)
assert set(certificate['results'])==set(map(str,range(201)))
c=json.loads((p/'candidate.json').read_text());L,B,n,expanded,mass,digest=validate(c);step,last=net_check(c);m=json.loads((p/'manifest.json').read_text())
assert n==50 and L==F('7.35') and mass==F('49.99999') and digest==m['candidate_digest']
assert net_certificate(B,step,last)==m['net'] and last==200
source=(root/'src/unified_linear_verify.cpp').read_bytes();assert hashlib.sha256(source).hexdigest()==m['source_sha256']
records=[]
for j in range(201):
 q=p/f'net{j:03}';r=json.loads((q/'result.json').read_text());m2=r['manifest'];assert r['status']=='ANGLE_VERIFIED' and not r['frontier'] and not r['exact_witnesses'];assert m2['index']==j and m2['candidate_digest']==digest;assert hashlib.sha256((q/'input.txt').read_bytes()).hexdigest()==m2['input_sha256'];assert (q/'verify.cpp').read_bytes()==source
 records.append(dict(index=j,input_sha256=m2['input_sha256'],result_sha256=hashlib.sha256((q/'result.json').read_bytes()).hexdigest()))
D=10**90;bounds={}
for v in (2,14):
 q=math.isqrt(v*D*D);assert q*q<=v*D*D<(q+1)*(q+1);bounds[v]=(F(q,D),F(q+1,D))
green=2*bounds[2][1]-1+(F(7*6**2)+6*bounds[14][1])/50;assert L>green
assert certificate['candidate_digest']==digest==summary['candidate_digest']
assert certificate['n']==n and F(certificate['L'])==L and F(certificate['B'])==B
assert F(certificate['total_mass'])==mass and F(certificate['budget_gap'])==n-mass
assert certificate['angle_count']==201 and certificate['net']==m['net']
assert certificate['source_sha256']==m['source_sha256']
assert (p/'verify.cpp').read_bytes()==source
for row in records:
 j=row['index'];stored=json.loads((p/f'net{j:03}'/'result.json').read_text())
 replay=certificate['results'][str(j)]
 assert replay==dict(index=j,status='LINEAR_ANGLE_REPLAYED',input_sha256=row['input_sha256'],nodes=stored['nodes'])
 assert summary['records'][str(j)]['status']=='ANGLE_VERIFIED'
 assert summary['records'][str(j)]['nodes']==stored['nodes']
report=dict(status='FINAL_CERTIFICATE_AUDITED',globally_verified=True,n=n,L=str(L),mass=str(mass),budget_gap=str(n-mass),candidate_digest=digest,green_upper=str(green),improvement_lower=str(L-green),net=m['net'],records=records,certificate_sha256=hashlib.sha256((p/'certificate.json').read_bytes()).hexdigest(),replay_scope=certificate['replay_scope'],provenance='Direct structured L7.40 rectangle initialization contracted to L7.35, followed by nonnegative minimum-L1 repair retaining native rows and exact deficit witnesses. Does not establish L7.40.')

print(json.dumps(dict(status=report['status'],all_angles=len(records),mass=str(mass),improvement_lower_float=float(L-green),globally_verified=True)))
