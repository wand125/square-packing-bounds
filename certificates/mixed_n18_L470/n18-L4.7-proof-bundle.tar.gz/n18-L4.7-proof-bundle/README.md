# Mixed density and point proof: n=18, L=4.7

Every one of the 416 net angles has passed complete centre coverage and replay.
The exact mass is 1799999/100000 < 18.
Candidate SHA256: `c860286b313b276993ecf1b0583d9c3df393908deb2bbda86d44223537541f8f`.

## Reproduce

Use Python 3, NumPy, and a C++17 compiler named `c++`. From this directory:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 code/verify_mixed_full_proof.py proof --workers 3
```

The checker regenerates inputs from the rational candidate, checks symmetry,
angle-net containment and budgets, rechecks the axis integer tables, compiles
the supplied C++ source without fast-math or FMA contraction, and re-executes
all 415 oblique centre-domain proofs. Recorded original filesystem paths are
provenance only: replay uses this bundle's candidate and checks its digest.

## Mathematical implication

D4 symmetry reduces orientations to [0, pi/4]. The half-angle net has step
1/1001 and 416 nodes. B=0.999 satisfies B*(1+1/1001)<1, so each original
unit square contains a closed net-angle core strictly in its interior.
All required centres at every net node have core measure >=1. Cores selected
inside distinct nonoverlapping packing squares are disjoint, including their
boundaries; hence their total measure would be >=n, contradicting total mass<n.

The axis table replay is independent of the generating table formula. Oblique
replay uses the SAME outward-rounded algorithm, not an independent second
implementation and not a proof-assistant formalization. No Nagamochi score
lemma is used.

`files-sha256.json` records the untouched bundle. Replay regenerates report
files and a binary; validate these hashes before replay if checking integrity.
The numerical search, LP solver and random probes are not trusted inputs to
the proof checker. Publication is a separate step.
