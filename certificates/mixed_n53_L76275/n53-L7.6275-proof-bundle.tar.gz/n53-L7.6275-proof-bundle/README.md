# Mixed density and point proof: n=53, L=7.6275

Every one of the 201 net angles has passed complete centre coverage and replay.
The exact mass is 5299999/100000 < 53.
Candidate SHA256: `796fcf86fa805b3d7c746aac1dd60f83b25bb0bcbee2ec3b3caf7f5f2532bd5a`.

## Reproduce

Use Python 3, NumPy, and a C++17 compiler named `c++`. From this directory:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 code/verify_mixed_full_proof.py proof --workers 3
```

The checker regenerates inputs from the rational candidate, checks symmetry,
angle-net containment and budgets, rechecks the axis integer tables, compiles
the supplied C++ source without fast-math or FMA contraction, and re-executes
all 200 oblique centre-domain proofs. Recorded original filesystem paths are
provenance only: replay uses this bundle's candidate and checks its digest.

## Mathematical implication

D4 symmetry reduces orientations to [0, pi/4]. The half-angle net has step
83/40000 and 201 nodes. B=0.9977 satisfies B*(1+83/40000)<1, so each original
unit square contains a closed net-angle core strictly in its interior.
All required centres at every net node have core measure >=1. Cores selected
inside distinct nonoverlapping packing squares are disjoint, including their
boundaries; hence their total measure would be >=n, contradicting total mass<n.

The axis table replay is independent of the generating table formula. Oblique
replay uses the SAME outward-rounded algorithm, not an independent second
implementation and not a proof-assistant formalization. No Nagamochi score
lemma is used.

`files-sha256.json` records the untouched bundle. Replay regenerates report
files and a binary; validate these hashes before replay if checking integrity.
The numerical search, LP solver and random probes are not trusted inputs to
the proof checker. Publication is a separate step.
